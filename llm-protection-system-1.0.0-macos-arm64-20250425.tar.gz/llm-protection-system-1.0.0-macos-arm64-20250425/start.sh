#!/bin/bash
open "本地大模型防护系统.app"
